#######################################################
# 01/11/2022, Zhichao Peng, MSU
# This is a demo code to demonstrate how to use WaveHoltz
# to convert a time-domain solver to a frequency-domain one.
#
# 1D Wave/Maxwell equation:
# iω(Ez) = ∂ₓHy - J
# iω(Hy) = ∂ₓEz
# with PEC boundary condition on [0,1] is considered.
# 
# The current source J is chosen so that 
# Ez = 0+ 1j x(1-x) is an exact solution.
#
# We use the EM-WaveHoltz to compute the imaginary part of 
# the exact solution.
########################################################
# Include subroutine to define Yee spatial discretization
include("yee_space.jl")
using IterativeSolvers
using Plots
pyplot()
##################################
# Step 1: set up of the problem
##################################
omega = 25.5
N_mesh = 400
N = N_mesh+1

# Define the mesh
x_l = 0.0
x_r = 1.0
x_grid = LinRange(x_l,x_r,N)
h = (x_r-x_l)/N_mesh

# Imaginary part of the exact solution
function E_exact_imaginary(x)
    return x*(1-x)
end

# Define the source function so that E_exact_imaginary will be a solution with PEC boundary conditions
function J_function(x)
    return omega*E_exact_imaginary(x)-2/omega
end

############################################
# Step 2: set up the spatial discretization
############################################
# Get the spatial discretization of the Yee scheme
DE,DH = assemble_1D_discretization(N,h);
# evolve for N periods in the time domain
N_period = 10
time_final = 2.0*pi/omega#*N_period
# time step size
CFL = 1.0
dt = CFL*h
N_time =ceil(time_final/dt)
dt = time_final/N_time

#######################################################
# Step 3: define the lienar operator for the WaveHoltz
#######################################################
# source in the time-domain
function J_contribution(time)
    res = zeros(N)
    for i = 2:N-1
        res[i] = sin(omega*(time))*J_function(x_grid[i])
    end
    return res
end

# evolve the time-domain equations for multiple periods
function time_domain_evolution!(E_integral, E_initial)
    # initial conditions
    H_old = zeros(length(E_initial)-1)
    H = copy(H_old)
    E_old = copy(E_initial)
    E = copy(E_old)
    # backward half step evolution for H
    H = H_old - 0.5*dt*DE*E
    #println(H_new-H)
    # integral term
    stepsize = 2/N_time
    eta = 0.5
    E_integral .= E.*stepsize*eta*0.75
    # time evolution
    time = 0.0;
    eta  = 1.0;
    for i = 1:N_time
        H_old = copy(H)
        E_old = copy(E)
        # one step for H
        H = H_old + dt*DE*E
        #####################
        # one step for E
        #####################
        # contribution from H and the boundary condition
        E = E_old + dt*(DH*H-J_contribution(time+0.5*dt))
        #############################
        # update the filter operator
        #############################
        time = time+dt
        if(i==N_time)
            eta = 0.5
        end
        E_integral .+= E.*stepsize*eta*(cos(omega*time)-0.25)
    end
end

# compute PI 0
zero_vec = zeros(N)
PI_zero = zeros(N)
time_domain_evolution!(PI_zero,zero_vec)

# Operator (I-S)v = (I-Π)v + Π0
function I_minus_S!(res,v)
    PI_v = copy(res)
    # use time domain simulation to compute Πv
    time_domain_evolution!(PI_v,v)
    res .= v-PI_v+PI_zero
end
#######################################################
# Step 4: test
#######################################################
# Set up the exact solution
E_exact_imag = zeros(N)
for i = 1:N
    E_exact_imag[i] = E_exact_imaginary(x_grid[i])
end

# Set up the initial guess
E_initial_guess = zeros(N)
# Julia interface to define matrix-vector multiplication provided by matrix-free operations
I_minus_S_operator = LinearMap(I_minus_S!,N,issymmetric=true)
# Use CG to solve the linear problem (I-S)v=Π0. The solution gives us the imaginary part of the frequency-domain solution
# CG can only be utlized for the energy-conserving case with ω not being a resonance frequency. In other situations, one
# should use GMRES/BiCG-Stab. 
@time E_imag,convergence_history = cg(I_minus_S_operator,PI_zero,reltol=1e-12,log=true)


# Print error
println("l2 error: ",norm(E_exact_imag-E_imag,Inf))
println(convergence_history)

# Visulize the solution
fig = plot(x_grid,E_exact_imag,lab="Exact",legend=:best)
plot!(fig,x_grid,E_imag,lab="WaveHoltz",legend=:best)
display(fig)

# Convergence history
fig2 = plot(convergence_history,yaxis=:log)
display(fig2)

