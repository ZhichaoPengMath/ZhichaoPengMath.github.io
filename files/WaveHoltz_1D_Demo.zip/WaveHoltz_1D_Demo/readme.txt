01/11/2022
This is a simple demo Julia code written by Zhichao Peng to demonstrate how to use 
WaveHoltz to convert a time-domain Yee solver to a frequency-domain solver. A simple
1D problem with PEC boundary conditions is considered.

If you have never used Julia before, we recommend you to check 

https://julialang.org/ 

and 

https://www.julia-vscode.org/docs/stable/ 

on how to install and run Julia code with an IDE.

