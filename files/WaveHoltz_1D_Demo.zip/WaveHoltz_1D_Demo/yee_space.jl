using LinearAlgebra, SparseArrays, IterativeSolvers
using LinearMaps
# N number of nodal points for E
function assemble_1D_discretization(N,h)
####################################################
# matrices for the central difference
# on staggered grid
####################################################
    # allocate memory
    # assign values for the discretization of Hx
    rows = zeros(Int64,2*(N-2))
    cols = zeros(Int64,2*(N-2))
    vals = zeros(Float64,2*(N-2))
    ind = 1
    for i = 2:N-1
        rows[ind]   = i
        rows[ind+1] = i
        cols[ind]   = i-1
        cols[ind+1] = i
        vals[ind]   = -1.0/h
        vals[ind+1] = 1.0/h
        ind += 2
    end
    DH = sparse(rows,cols,vals,N,N-1)

    # assign values for the discretization of Ex
    rows = zeros(Int64,2*(N-1))
    cols = zeros(Int64,2*(N-1))
    vals = zeros(Float64,2*(N-1))
    ind = 1
    for i = 1:N-1
        rows[ind]   = i
        rows[ind+1] = i
        cols[ind]   = i
        cols[ind+1] = i+1
        vals[ind]   = -1.0/h
        vals[ind+1] = 1.0/h
        ind += 2
    end
    DE = sparse(rows,cols,vals,N-1,N)
    return DE,DH
#    return PEC_1D,DE,DH
end
